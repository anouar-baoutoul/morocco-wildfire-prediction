# Analyse univariée - EMSI
Le PDF comprend une introduction et une fiche pour chacune des 17 colonnes.
Les premières fiches détaillent temperature_2m_max (numérique) et feu (qualitative).
Les statistiques et fréquences sont aussi fournies en CSV.

Reproduire : installer pandas, numpy, reportlab puis lancer `python analyse_univariee.py` dans ce dossier. Le dataset doit rester à côté du script.
Les graphiques utilisent les unités originales. Aucune normalisation n'a modifié le dataset source. Les choix et formules proposés sont documentés pour chaque variable ; tout ajustement appris se fait sur l'entraînement uniquement.
Le support de cours n'a pas été fourni : les graphes retenus sont les histogrammes, boîtes à moustaches et diagrammes en barres usuels.
