from pathlib import Path
import pandas as pd, numpy as np, json, hashlib, zipfile, shutil
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
for name,filename in [('Corps','calibri.ttf'),('Titre','georgia.ttf'),('Gras','calibrib.ttf')]:
 pdfmetrics.registerFont(TTFont(name,str(Path('C:/Windows/Fonts')/filename)))
TITLES={'temperature_2m_max':'La température maximale','feu':'La présence de feu','id_observation':"Le numéro d’observation",'lat_c':'La latitude des observations','lon_c':'La longitude des observations','acq_date':"La date d’observation",'mois':"Le mois de l’année",'jour_annee':"Le jour dans l’année",'date':'La date associée à la météo','precipitation_sum':'Les précipitations','wind_speed_10m_max':'La vitesse maximale du vent','humidite_moy':"L’humidité moyenne",'lat_grille':'La latitude de la grille météo','lon_grille':'La longitude de la grille météo','origine_meteo':"D’où viennent les données météo ?",'statut_geo':'La position par rapport au contour','distance_grille_km':'La distance à la grille météo'}
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import simpleSplit
ROOT=Path(__file__).resolve().parent
source=ROOT/'dataset_feux_meteo_prepare.csv'
df=pd.read_csv(source)
N=len(df)
OUT=ROOT
C=canvas.Canvas(str(OUT/'Analyse_Univariee_EMSI.pdf'),pagesize=(595,842))
BLUE='#2474b5'; DARK='#222222'; ORANGE='#e88b28'
def text(x,y,s,size=10,color=DARK):
 C.setFillColor(HexColor(color));C.setFont('Corps',size);C.drawString(x,y,str(s))
def para(s,y,size=10):
 for line in simpleSplit(s,'Corps',size,495):text(50,y,line,size);y-=15
 return y-8
def header(title,sub):
 C.setFillColor(HexColor('#ffffff'));C.rect(0,0,595,842,stroke=0,fill=1)
 C.setFillColor(HexColor(DARK));C.setFont('Titre',22)
 C.drawString(50,788,TITLES.get(title,title))
 text(50,761,(title+'  /  '+sub) if title in TITLES else sub,10,'#697572')
 C.setStrokeColor(HexColor('#cbd5ce'));C.line(50,745,545,745)
def finish():
 text(520,29,str(C.getPageNumber()),9,'#697572');C.showPage()
def fmt(v):return f'{v:,.3f}'.replace(',',' ').replace('.',',') if isinstance(v,(float,np.floating)) else str(v)
def bars(labels,values,title,y=410,histogram=False):
 text(50,y,title,11); x0,y0,w,h=72,y-185,455,145
 maximum=max(values) or 1
 C.setStrokeColor(HexColor('#333333'));C.line(x0,y0,x0+w,y0);C.line(x0,y0,x0,y0+h)
 for frac in [0,.5,1]:text(42,y0+frac*h, str(round(maximum*frac)),8)
 step=w/len(values)
 for i,(label,v) in enumerate(zip(labels,values)):
  C.setFillColor(HexColor(BLUE));C.rect(x0+i*step+(0 if histogram else 3),y0,max(1,step-(0 if histogram else 6)),v/maximum*h,fill=1,stroke=0)
  text(x0+i*step+4,y0-17,str(label),8)
 text(50,y0+h+10,'Effectif (lignes)',9)
def hist_box(s,unit):
 counts,edges=np.histogram(s,bins=20)
 bars([str(round(v,1)) if i%4==0 else '' for i,v in enumerate(edges[:-1])],counts,'Histogramme - 20 classes de même largeur',410,histogram=True)
 text(200,194,unit,9)
 q1,med,q3=s.quantile([.25,.5,.75]);iqr=q3-q1
 low=s[s>=q1-1.5*iqr].min();high=s[s<=q3+1.5*iqr].max()
 mn,mx=s.min(),s.max();scale=lambda v:75+(v-mn)/(mx-mn or 1)*450
 text(50,164,'Boîte à moustaches - règle de Tukey (1,5 x IQR)',11)
 C.setStrokeColor(HexColor(BLUE));C.setFillColor(HexColor('#d9eafa'))
 C.line(scale(low),127,scale(high),127);C.rect(scale(q1),115,max(.5,scale(q3)-scale(q1)),24,stroke=1,fill=1)
 for v in [low,med,high]:C.line(scale(v),112,scale(v),142)
 outs=s[(s<low)|(s>high)]
 for v in np.unique(outs):C.circle(scale(v),127,1,stroke=1,fill=0)
 for v in [mn,mx]:text(scale(v)-7,96,fmt(float(v)),8)
 text(230,96,unit,9)
 text(50,67,'La boîte contient les 50 % centraux ; le trait indique la médiane.',9,'#697572')
 text(50,54,'Les points au-delà des moustaches ne sont pas forcément des erreurs.',9,'#697572')
units={'temperature_2m_max':'Température (°C)','precipitation_sum':'Précipitations (mm)','wind_speed_10m_max':'Vent (km/h)','humidite_moy':'Humidité relative (%)','lat_c':'Latitude (degrés)','lon_c':'Longitude (degrés)','lat_grille':'Latitude grille (degrés)','lon_grille':'Longitude grille (degrés)','distance_grille_km':'Distance (km)','jour_annee':"Jour de l'année",'id_observation':'Identifiant'}
plans={
 'temperature_2m_max':"Pour une régression logistique ou un SVM, on peut utiliser z = (x - moyenne) / écart-type. À titre descriptif, 30 °C correspond ici à environ 0,60 écart-type au-dessus de la moyenne. Les arbres n'exigent pas cette transformation.",
 'precipitation_sum':"Transformation log1p(x) proposée pour réduire l'asymétrie et conserver les zéros, puis centrage-réduction si nécessaire. log1p suppose ici les valeurs numériques exprimées en mm.",
 'wind_speed_10m_max':"Centrage-réduction si modèle sensible aux échelles ; conserver les vents forts plausibles. Un RobustScaler peut être comparé si les extrêmes déstabilisent le modèle.",
 'humidite_moy':"Division par 100 pour obtenir une proportion entre 0 et 1 : bornes physiques connues, sans estimation sur les données.",
 'distance_grille_km':"Aucune normalisation pour le modèle principal : variable d'audit, à exclure des prédicteurs par défaut.",
 'id_observation':"Aucune normalisation. Identifiant technique à exclure des prédicteurs ; ses statistiques n'ont pas de sens environnemental.",
 'jour_annee':"Encodage cyclique sin(2*pi*(jour-1)/L) et cos(2*pi*(jour-1)/L), avec L=365 ou 366 selon l'année. Évite de séparer artificiellement fin et début d'année.",
 'mois':"Encodage cyclique sin(2*pi*(mois-1)/12) et cos(2*pi*(mois-1)/12) si prédicteur. Ce n'est pas une normalisation numérique classique.",
 'feu':"Aucune normalisation : cible qualitative binaire, déjà codée 0/1. Ne pas standardiser les étiquettes.",
 'origine_meteo':"Aucune normalisation : variable qualitative de traçabilité à exclure des prédicteurs par défaut.",
 'statut_geo':"Aucune normalisation : variable qualitative de contrôle à exclure des prédicteurs par défaut.",
 'acq_date':"Pas de normalisation directe d'une date. Extraire des variables calendaires pertinentes et réaliser une séparation chronologique pour le modèle.",
 'date':"Pas de normalisation directe. Colonne identique à acq_date : conserver une seule date dans les prédicteurs dérivés."}
for col in ['lat_c','lon_c']:plans[col]="Aucune transformation pour la description géographique. Centrage-réduction possible pour un modèle sensible aux échelles ; les degrés ne sont pas des distances en kilomètres."
for col in ['lat_grille','lon_grille']:plans[col]="Aucune normalisation pour l'analyse. Centre de grille météo, conservé comme métadonnée ; éviter de l'ajouter automatiquement aux coordonnées d'observation comme prédicteur redondant."
header('Comprendre nos données','Analyse univariée des observations de feux au Maroc · 2018–2025')
y=715
for p in ['Adam TALIBI et Anouar BAOUTOUL - EMSI - 2026/2027',f'{N:,} observations, 17 variables, du 01/01/2018 au 31/12/2025.'.replace(',',' '),'Avant de construire un modèle, nous avons cherché à comprendre ce que contient notre base : quelles valeurs sont fréquentes, comment elles se dispersent et quelles précautions prendre pour les utiliser.',"Les deux premières fiches constituent le premier rendu demandé. Les quinze autres fiches étendent la même démarche à toutes les colonnes.","Méthode : moyenne, médiane, modes, quartiles, étendue, variance et écart-type échantillonnaux (diviseur n-1), asymétrie corrigée de Fisher-Pearson. Quartiles calculés par interpolation linéaire. Les extrêmes de Tukey sont des signaux à examiner, pas des erreurs à supprimer.","Graphiques usuels retenus faute de support de cours fourni : histogramme et boîte à moustaches pour les mesures numériques ; diagrammes en barres pour les catégories et effectifs annuels pour les dates.","Les distributions portent sur les lignes de cet échantillon : une même zone apparaît à plusieurs dates. Elles ne décrivent pas une population de zones indépendantes et ne donnent pas un risque national d'incendie.","La normalisation n'est pas nécessaire pour calculer ces statistiques. Les choix proposés préparent une éventuelle modélisation. Tout paramètre appris doit être ajusté sur le jeu d'entraînement uniquement.","Source : dataset_feux_meteo_prepare.csv, issu du fichier fourni, complété avec Open-Meteo. Provenance FIRMS déclarée ; protocole de construction des feu=0 non documenté."]:
 y=para(p,y,11)
finish()
records=[]
order=['temperature_2m_max','feu']+[c for c in df if c not in ['temperature_2m_max','feu']]
for col in order:
 s=df[col];numeric=col in units
 header(col,'Variable '+('numérique' if numeric else 'temporelle' if col in ['date','acq_date'] else 'qualitative / calendaire'))
 y=715;y=para(f'Effectif : {s.notna().sum()} ; valeurs manquantes : {s.isna().sum()} ; valeurs distinctes : {s.nunique()}.',y)
 record={'variable':col,'effectif':int(s.count()),'manquantes':int(s.isna().sum()),'distinctes':int(s.nunique()),'normalisation':plans[col]}
 if numeric:
  q1,med,q3=s.quantile([.25,.5,.75]);iqr=q3-q1;outside=int(((s<q1-1.5*iqr)|(s>q3+1.5*iqr)).sum());modes=s.mode(); modeval=', '.join(fmt(float(v)) for v in modes[:3])+(' ...' if len(modes)>3 else '')
  metrics={'moyenne':s.mean(),'mediane':med,'variance_n_1':s.var(),'ecart_type_n_1':s.std(),'minimum':s.min(),'q1':q1,'q3':q3,'maximum':s.max(),'etendue':s.max()-s.min(),'iqr':iqr,'asymetrie':s.skew(),'hors_tukey':outside}
  record.update(metrics)
  for line in [f"Moyenne : {fmt(s.mean())} ; médiane : {fmt(med)} ; écart-type : {fmt(s.std())}.",f"Variance (unité au carré) : {fmt(s.var())} ; min : {fmt(float(s.min()))} ; max : {fmt(float(s.max()))}.",f"Q1 : {fmt(q1)} ; Q3 : {fmt(q3)} ; IQR : {fmt(iqr)} ; étendue : {fmt(float(s.max()-s.min()))}.",f"Mode(s) : {modeval} ({len(modes)} mode(s)) ; asymétrie : {fmt(s.skew())}.",f"Valeurs éloignées selon la règle de Tukey : {outside} ({outside/N:.2%})."]:y=para(line,y,10)
  interpretation=f"Dans notre échantillon, une observation sur deux se situe entre {fmt(q1)} et {fmt(q3)}. "
  interpretation+=('Quelques valeurs élevées prolongent la distribution vers la droite.' if s.skew()>.5 else 'La distribution se prolonge davantage du côté des faibles valeurs.' if s.skew()<-.5 else "Les valeurs se répartissent de façon assez équilibrée autour du centre, sans que cela prouve une distribution normale.")
  if col=='precipitation_sum':interpretation+=f' Les zéros représentent {(s==0).mean():.2%} des observations.'
  if col=='id_observation':interpretation="Les identifiants sont uniques et séquentiels. Leur distribution reflète la numérotation, sans interprétation climatique. Les mesures sont fournies uniquement pour exhaustivité."
  if col=='jour_annee':interpretation="Le jour de l'année est cyclique. Moyenne et médiane linéaires restent descriptives, mais masquent la proximité entre décembre et janvier."
  if col.startswith('lat') or col.startswith('lon'):interpretation+=" La distribution décrit l'échantillonnage spatial, pas la répartition nationale des incendies."
  y=para(interpretation,y,10)
  y=para('Faut-il transformer cette variable ? '+plans[col],y,10)
  hist_box(s,units[col])
 elif col in ['date','acq_date']:
  dates=pd.to_datetime(s);counts=dates.dt.year.value_counts().sort_index();mode=dates.mode()
  y=para(f"Première date : {dates.min().date()} ; dernière date : {dates.max().date()} ; étendue : {(dates.max()-dates.min()).days} jours.",y)
  y=para(f"Date(s) modale(s) : {', '.join(str(v.date()) for v in mode[:3])} ; effectif maximal à une date : {dates.value_counts().max()}.",y)
  y=para("Les barres mesurent le nombre de lignes échantillonnées par année, pas le nombre d'incendies distincts. Les dates ne forment pas nécessairement une série continue pour chaque lieu.",y)
  y=para('Faut-il transformer cette variable ? '+plans[col],y)
  bars(counts.index.astype(str).tolist(),counts.tolist(),'Distribution des observations par année',480)
  counts.rename_axis('annee').to_csv(OUT/(col+'_effectifs.csv'))
  record.update({'min_date':str(dates.min().date()),'max_date':str(dates.max().date())})
 else:
  counts=s.value_counts().sort_index();freq=counts/N
  for k,v in counts.items():y=para(f'{k} : {v} observations ({v/N:.2%}).',y,10)
  mode=counts.idxmax();y=para(f'Mode : {mode}. Part de la modalité dominante : {counts.max()/N:.2%}.',y)
  if col=='feu': interp="0 : absence de feu selon l'étiquette fournie ; 1 : présence selon l'étiquette fournie. La catégorie 0 est majoritaire. Ce déséquilibre modéré doit guider l'évaluation future, mais les fréquences ne sont pas des probabilités nationales de feu. Moyenne et variance des codes ne sont pas retenues comme mesures qualitatives."
  elif col=='mois':interp="Le mois est une catégorie ordonnée et cyclique. Les fréquences décrivent la répartition saisonnière des lignes, sans établir un lien causal avec les incendies."
  elif col=='origine_meteo':interp="La majorité de la météo a été récupérée lors du complément. Cette variable documente la provenance, pas une condition environnementale."
  else:interp="Les centres en bordure sont conservés pour vérification. Le signalement n'affirme ni une erreur de coordonnées ni une position initiale hors du Maroc."
  y=para(interp,y);y=para('Faut-il transformer cette variable ? '+plans[col],y)
  labels=[str(x) for x in counts.index]
  if col=='feu':labels=['Sans feu (0)', 'Avec feu (1)']
  if col=='origine_meteo':labels=['Initiale' if 'presente' in x else 'Récupérée' for x in labels]
  if col=='statut_geo':labels=['Dans contour' if x=='centre_dans_contour' else 'Bordure' for x in labels]
  bars(labels,counts.tolist(),'Diagramme en barres - effectifs par modalité',min(420,y-15))
  pd.DataFrame({'effectif':counts,'frequence':freq,'pourcentage':freq*100}).to_csv(OUT/(col+'_effectifs.csv'))
  record['mode']=str(mode)
 records.append(record);finish()
C.save()
pd.DataFrame(records).to_csv(OUT/'statistiques_toutes_variables.csv',index=False,encoding='utf-8-sig')
(OUT/'README.md').write_text('''# Analyse univariée - EMSI
Le PDF comprend une introduction et une fiche pour chacune des 17 colonnes.
Les premières fiches détaillent temperature_2m_max (numérique) et feu (qualitative).
Les statistiques et fréquences sont aussi fournies en CSV.

Reproduire : installer pandas, numpy, reportlab puis lancer `python analyse_univariee.py` dans ce dossier. Le dataset doit rester à côté du script.
Les graphiques utilisent les unités originales. Aucune normalisation n'a modifié le dataset source. Les choix et formules proposés sont documentés pour chaque variable ; tout ajustement appris se fait sur l'entraînement uniquement.
Le support de cours n'a pas été fourni : les graphes retenus sont les histogrammes, boîtes à moustaches et diagrammes en barres usuels.
''',encoding='utf8')
print(df['temperature_2m_max'].describe().to_string());print('PDF produit ; 17 variables analysées.')


